/*******************************************************************************
 * ADOBE CONFIDENTIAL
 *  ___________________
 *
 *   Copyright 2017. Adobe Systems Incorporated
 *   All Rights Reserved.
 *
 *  NOTICE:  All information contained herein is, and remains
 *  the property of Adobe Systems Incorporated and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to Adobe Systems Incorporated and its
 *  suppliers and are protected by all applicable intellectual property
 *  laws, including trade secret and copyright laws.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from Adobe Systems Incorporated.
*****************************************************************************/

//Customized Version for DeuBa Submit from Agent UI, KP 15.10.2018
var SubmitServiceDelegate;
(function (CM) {
    /**   SubmitServiceDelegate */
    SubmitServiceDelegate = CM.services.SubmitServiceDelegate = {};

    SubmitServiceDelegate.submitLetter = function (letter, letterData, interactive, context, successHandler, faultHandler) {
        interactive = interactive !== undefined ? interactive : false;
        SubmitServiceDelegate.submitLetterWithParams(letter, letterData, interactive, false, false, null, null, context, successHandler, faultHandler);
    };
    SubmitServiceDelegate.submitLetterWithParams = function (letter, letterData, interactive, useLatestAssets, reload, serviceName, params, context, successHandler, faultHandler) {
        interactive = interactive !== undefined ? interactive : false;
        useLatestAssets = useLatestAssets !== undefined ? useLatestAssets : false;
        reload = reload !== undefined ? reload : false;
        serviceName = serviceName !== undefined ? serviceName : null;
        params = params !== undefined ? params : null;

        if (!letter)
            return new ImmediateFaultToken(new FaultEvent(FaultEvent.FAULT, false, new Fault("Submit Error", "invalid letter object provided; cannot submit letter")),
                this.className + ".submitLetterWithParams");

        if (!letterData)
            return new ImmediateFaultToken(new FaultEvent(FaultEvent.FAULT, false, new Fault("Submit Error", "invalid data provided; cannot submit letter")),
                this.className + ".submitLetterWithParams");

        var appConfig = AppConfigInitializer.getInstance();
        if (appConfig.configurationInstance) {
            var flexConfig = appConfig.configurationInstance;
            var multipartService = new MultipartUrlService();
            multipartService.appContext = AppConfigInitializer.CM_APPLICATION_CONTEXT;
            
//KP customized link for submit to circumvent standard /libs/ URL            
//            multipartService.url = flexConfig.submitServiceUrl + ".json";
            multipartService.url = flexConfig.submitServiceUrl.replace("/libs/","/apps/") + ".json";
//KP end
            multipartService.resultFormat = MultipartUrlService.RESULT_FORMAT_E4X;
            multipartService.charset = "UTF-8"; // the Submit Servlet only supports UTF-8
            multipartService.showBusyCursor = true;

            multipartService.setParameter("letterId", letter.id, null);
            multipartService.setParameter("xmlData", letterData, "text/xml");
            multipartService.setParameter("renderInteractive", interactive ? "true" : "false", null);
            multipartService.setParameter("useLatestAssets", useLatestAssets ? "true" : "false", null);
            multipartService.setParameter("reload", reload ? "true" : "false", null);
            multipartService.setParameter("serviceName", serviceName, null);
            //Set extra params
            for (var key in params)
                multipartService.setParameter(key, params[key], null);

            multipartService.send(context,
                function (responseXml) {
                    if (Debug.getInstance().allowLargeOutput)
                        Debug.info("submit servlet response:\n" + (responseXml ? XmlHelper.print(responseXml, {prettyPrinting: true}) : 'null'));
                    else
                        Debug.info("obtained submit servlet response: " + (responseXml ? "xml" : "null"));

                    var response = {redirect: null};
                    if (responseXml) {
                        var redirectXmlList = responseXml.elements(SubmitServiceDelegate._ELEM_REDIRECT);
                        if (redirectXmlList.length() > 0) {
                            var redirect = redirectXmlList[0].toString(); // get the content (will be empty string if element is empty)
                            response.redirect = redirect ? redirect : null;
                        }

                        var errorMsgXmlList = responseXml.elements(SubmitServiceDelegate._ELEM_ERROR_MESSAGE);
                        if (errorMsgXmlList.length() > 0) {
                            var errormessage = errorMsgXmlList[0].toString();
                            response.errormessage = errormessage ? errormessage : null;
                        }
                    }

                    var submitResult = new ResultEvent(ResultEvent.RESULT, response);
                    if (successHandler)
                        successHandler.call(context, response);
                },
                // multipart service fault handler
                function (multipartEvent) {
                    Debug.error("failed to submit " + letter + " to submit service:\n\t", multipartEvent);
                    var multipartFault = new Fault("Submit Error", "failed to submit " + letter + " to submit service");
                    multipartFault.rootCause = multipartEvent;
                    if (faultHandler)
                        faultHandler.call(this, new FaultEvent(FaultEvent.FAULT, false, multipartFault));
                });
        }
        else {

            Debug.error("failed to determine URL for submit service:\n\t");
            var configFault = new Fault("Submit Error", "failed to determine URL for submit service");
            if (faultHandler)
                faultHandler(this, new FaultEvent(FaultEvent.FAULT, false, configFault));
        }

    };

    /** Submit response root element. */
    SubmitServiceDelegate._ELEM_SUBMIT_RESPONSE = "iccSubmitResponse";
    /** Redirect element. */
    SubmitServiceDelegate._ELEM_REDIRECT = "redirect";
    /**Error Message.*/
    SubmitServiceDelegate._ELEM_ERROR_MESSAGE = "errormessage";
})(CM);
