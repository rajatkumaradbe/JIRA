<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~ ADOBE CONFIDENTIAL
~  ___________________
~
~   Copyright 2021. Adobe Incorporated
~   All Rights Reserved.
~
~  NOTICE:  All information contained herein is, and remains
~  the property of Adobe Incorporated and its suppliers,
~  if any.  The intellectual and technical concepts contained
~  herein are proprietary to Adobe Incorporated and its
~  suppliers and are protected by all applicable intellectual property
~  laws, including trade secret and copyright laws.
~  Dissemination of this information or reproduction of this material
~  is strictly forbidden unless prior written permission is obtained
~  from Adobe Incorporated.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div>
    <label>{{::data.labelField }}</label>
    <input data-somExp="{{::data.formSomExp}}" type="text" aria-label="{{::data.labelField}}" ng-class="{ngInvalid : !data.dataTypeValid}" title="{{::data.toolTip}}" ng-disabled="{{::!data.editable}}" ng-focus="focusInHandler()" ng-blur="focusOutHandler()"
           ng-trim="false" ng-model="data.value" ng-model-options="{ updateOn: 'blur' }">
    <span class="help-block">{{ data.dataTypeError }}</span>
</div>