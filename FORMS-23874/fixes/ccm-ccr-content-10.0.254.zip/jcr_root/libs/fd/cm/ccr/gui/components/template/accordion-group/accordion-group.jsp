<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="accordion-group">
    <div class="accordion-heading" >
        <div>
            <details class="accordion-toggle"  ng-init="isOpen=true" ng-open="isOpen" ng-click="isOpen = !isOpen" accordion-transclude="heading" >
                <summary>{{heading}}</summary>
            </details>
            <div style="display:inline;">
                <!--<button class="btn"><i class="icon-blankLine"></i></button>-->
                <i class="icon-lock"></i>
                <div class="unfilledVariables">&nbsp;0&nbsp;</div>
            </div>
        </div>
        <div class="accordion-body" collapse="!isOpen">
            <div class="accordion-inner" ng-transclude></div>
        </div>
    </div>
</div>
