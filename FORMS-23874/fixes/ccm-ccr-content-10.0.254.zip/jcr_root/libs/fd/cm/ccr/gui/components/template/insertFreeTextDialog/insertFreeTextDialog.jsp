
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="modal fade" id="insertFreeText" role="dialog" aria-hidden="true" ng-controller="FreeTextSettingCtrl">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" ng-click="onFreeTextDialogClose()" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">{{::I18n.getMessage("New Inline Text") }}</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-4 control-label">{{::I18n.getMessage("Name") }} *</label>
                        <div class="col-sm-6">
                            <input type="text" name="input" ng-model="moduleName" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">{{::I18n.getMessage("Description")}}</label>
                        <div class="col-sm-6">
                            <input type="text" name="input" ng-model="moduleDescription" class="form-control">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" ng-click="onFreeTextDialogClose()" data-dismiss="modal">{{::I18n.getMessage("Cancel") }}</button>
                <button type="button" class="btn btn-primary" ng-disabled="moduleName.trim().length == 0" ng-click="onFreeTextDialogClose();insertFreeText()">{{::I18n.getMessage("OK") }}</button>
            </div>
        </div>
    </div>
</div>