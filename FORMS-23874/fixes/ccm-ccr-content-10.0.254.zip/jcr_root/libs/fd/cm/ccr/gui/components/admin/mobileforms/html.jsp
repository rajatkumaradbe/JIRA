<%-- /*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/ --%>
<%@ page session="false" %>
<%@ page language="java" import="java.util.ArrayList" errorPage="" %>
<%@ page import="javax.jcr.*,
                 org.apache.sling.api.resource.Resource,
                 com.adobe.forms.external.utils.MFConstants,
                 com.adobe.fd.ccm.channels.print.fdinternal.util.DBConstants,
                 com.adobe.aemds.bedrock.CoreConfigService,
                 java.io.File "%>
<%@taglib prefix="sling" uri="http://sling.apache.org/taglibs/sling/1.0"%>
<%@taglib prefix="cq" uri="http://www.day.com/taglibs/cq/1.0" %>
<%@taglib prefix="ui" uri="http://www.adobe.com/taglibs/granite/ui/1.0" %>
<sling:defineObjects/><%
    slingRequest.setAttribute(MFConstants.SKIP_TRUSTED_CHECK,"true");
    String contentRoot = slingRequest.getParameter(MFConstants.CONTENT_ROOT);
    String template = slingRequest.getParameter(MFConstants.TEMPLATE);
    CoreConfigService coreConfigService = sling.getService(CoreConfigService.class);
    String cacheFolderPath = coreConfigService.getServerTempDir();
    boolean isValidContentRoot = true;//TODO contentRoot != null && contentRoot.startsWith(cacheFolderPath+"/");
    boolean isValidTemplate = DBConstants.EXTENDED_LAYOUT_CACHE_FILE_NAME.equals(template);
    if(isValidContentRoot && isValidTemplate){
        slingRequest.setAttribute(MFConstants.CONTENT_ROOT,contentRoot);
        slingRequest.setAttribute(MFConstants.TEMPLATE,template);
    }
%><!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta charset="UTF-8">
        <title>LC Forms</title>

        <script>
            window.addEventListener("FormBridgeInitialized",
            function(event) {
                var fb = event.detail.formBridge;
                fb.registerConfig("widgetConfig" ,
                {"div.richtextsupport" : "richTextWidget",
                 "div.checkboxfield" : "CMXfaCheckBox",
                 "div.radiofield" : "CMXfaCheckBox"});
            });

        </script>
        <cq:include script="/libs/xfaforms/profile/formRuntime.jsp"/>
        <ui:includeClientLib categories="cq.gui.ccr.widgets"/>
    </head>
    <body id="formBody">
        <ui:includeClientLib categories="cq.gui.ccr.widget"/>
        <ui:includeClientLib categories="adobesign.common"/>
        <cq:include script="/libs/xfaforms/profile/config.jsp"/>
        <cq:include script="/libs/xfaforms/profile/formBody.jsp"/>
    </body>
</html>
