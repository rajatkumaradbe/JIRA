
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="modal fade" id="listSettings" tabindex="-1" role="dialog" aria-hidden="true" ng-controller="NestedListSettingCtrl">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">{{::I18n.getMessage("Nested List Settings") }}</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-4 control-label">{{::I18n.getMessage("Indentation level") }}</label>
                        <div class="col-sm-6">
                            <input type="number" name="input"  min="0" max="10" ng-model="indentationLevel" class="form-control list_settings_indent" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">{{::I18n.getMessage("Bullet/Number Style")}}</label>
                        <div class="btn-group col-sm-6" role="group" aria-label="...">
                            <button type="button" ng-model="numberStyle"  btn-radio="'Maintain'" class="btn btn-default">{{::I18n.getMessage("Maintain")}}</button>
                            <button type="button" ng-model="numberStyle"  btn-radio="'Inherit'" class="btn btn-default">{{::I18n.getMessage("Inherit")}}</button>
                            <button type="button" ng-model="numberStyle"  btn-radio="'None'" class="btn btn-default">{{::I18n.getMessage("None")}}</button>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-6">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="input" ng-disable="!(numberStyle == 'Maintain' || numberStyle == 'Inherit')"  ng-model="compoundNumbering"> {{::I18n.getMessage("Compound number")}}
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">{{::I18n.getMessage("Cancel") }}</button>
                <button type="button" class="btn btn-primary" ng-click="applySettings()">{{::I18n.getMessage("Done") }}</button>
            </div>
        </div>
    </div>
</div>