<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div ng-controller="AttachmentPodCtrl" class="attachmentPodCtrl">
    <div class="actionButtons_search"  >
        <div class="actionBtns" ng-controller="ToolBarCtrl">
            <div class="badge ">{{attachmentCount}}</div>
            <span title="{{I18n.getMessage('Per letter design, you cannot reorder the content in this focus area or list.')}}" ng-show="attachmentInstance.orderLocked" class="btn-link btn"><i class="lock-icon"></i></span>
            <button class="btn-link btn" ng-disabled="!moveUpEnabled" ng-click="moveUpClickHandler()" title="{{I18n.getMessage('Move the selected content up.')}}"><i class="actUp"></i> </button>
            <button class="btn-link btn" ng-disabled="!moveDownEnabled" ng-click="moveDownClickHandler()" title="{{I18n.getMessage('Move the selected content down.')}}"><i class="actDown"></i></button>
            <button title="{{I18n.getMessage('The letter design permits you to add attachment from the Attachment Library.')}}" ng-click="showContentLibrary();$event.stopPropagation();" ng-show="attachmentInstance.open" class="btn-link btn"><i class="library-icon"></i></button>
        </div>
    </div>
    <div class="tree">
        <ul class="targetArea">
            <li ng-repeat="content in attachmentInstance.attachmentContents.toArray()" ng-click="onContentClick(content,$index)" class="subModuleLI">
                <article ng-class="{moduleInstanceSelected : content.userSelected, moduleInstanceItem : true}" tabindex="0">
                    <p class="actBtn_desc"><strong>{{content.displayName}}</strong></p>
                    <p class="actBtns" >
                        <span><i class="vHidden"></i></span>
                        <span><i class="vHidden"></i></span>
                        <span><i class="vHidden"></i></span>
                        <span><i class="vHidden"></i></span>
                        <button title="{{I18n.getMessage('Select to add attachment to the letter')}}" ng-disabled="!content.optional" ng-click="content.selected = !content.selected;onSelectionChange(content)" class="btn-link btn" tabindex="{{content.userSelected ? '0' : '-1'}}">
                            <i ng-class="{'eye-icon':content.selected,'no-view-icon':!content.selected}" ></i>
                        </button>
                        <button class="btn-link btn" ng-disabled="!content.optional"  ng-click="deleteClickHandler(content)" class="" title="{{I18n.getMessage('Delete the selected content..')}}" tabindex="{{content.userSelected ? '0' : '-1'}}">
                            <i class="delete-icon"></i>
                        </button>
                    </p>
                </article>
            </li>
        </ul>
    </div>
</div>
