<%-- /*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/ --%>
<%@include file="/libs/foundation/global.jsp"%>
<!DOCTYPE html lang="en" PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<%@page import="com.adobe.fd.df.fdinternal.util.UIHelper,
				com.adobe.fd.ccm.channels.print.fdinternal.util.DBConstants,
				com.adobe.fd.ccm.ccr.fdinternal.api.services.DataCacheService,
				com.day.cq.i18n.I18n,
				java.util.Map,
				java.util.HashMap,
				org.apache.sling.api.scripting.SlingScriptHelper,
				org.apache.commons.lang.StringUtils,
				org.apache.commons.lang.StringEscapeUtils,
				org.apache.sling.api.resource.*,
				java.util.Locale,
				java.util.ResourceBundle,
				com.adobe.granite.xss.XSSAPI,
				com.adobe.aemds.guide.utils.GuideUtils" %>
<%@page session="false" contentType="text/html; charset=utf-8"%>
<%@taglib prefix="sling" uri="http://sling.apache.org/taglibs/sling/1.0"%>
<%@taglib prefix="cq" uri="http://www.day.com/taglibs/cq/1.0" %>
<%@taglib prefix="ui" uri="http://www.adobe.com/taglibs/granite/ui/1.0" %>
<%!
	String getBrowserLocale(HttpServletRequest request){
		String acceptLang = request.getHeader("accept-language");
		if(acceptLang == null || "".equals(acceptLang.trim()))
			acceptLang = "en";
		acceptLang = acceptLang.trim();
		String[] locales = acceptLang.split(",");
		return locales[0];
	}
	String getParameterValue(HttpServletRequest request, String key) {
		String val = StringEscapeUtils.escapeJava(request.getParameter(key));
		if (StringUtils.isEmpty(val)) {
			return null;
		}
		return '"' + val + '"';
	}
	String getParameterValue(HttpServletRequest request, String key, XSSAPI xssAPI) {
		String val = StringEscapeUtils.escapeJava(request.getParameter(key));
		if (StringUtils.isEmpty(val)) {
			return null;
		}
		return '"' + xssAPI.encodeForJSString(val) + '"';
	}
	String getParamMapLocation(HttpServletRequest request, SlingScriptHelper sling, XSSAPI xssAPI) {
		// Store request attributes
		DataCacheService dataCacheService = sling.getService(DataCacheService.class);
		Map paramMap = (Map) request.getAttribute(DBConstants.PREFILL_SERVICE_PARAMS);
		String paramMapLocation = null;
		if(paramMap != null) {
			paramMapLocation = dataCacheService.storeData(paramMap);
		}
		if (StringUtils.isEmpty(paramMapLocation)) {
			return null;
		}
		return '"' + xssAPI.encodeForJSString(paramMapLocation) + '"';
	}
%>

<%
	Locale myLocale = new Locale(getBrowserLocale(request));
	ResourceBundle resourceBundle = slingRequest.getResourceBundle(myLocale);
	I18n i18n = new I18n(resourceBundle);
	String locale = GuideUtils.getLocale(slingRequest, resource);
	String categories = "guides.I18N."+locale;
%>
<cq:defineObjects />
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="UTF-8" />
	<title>Create Correspondence</title>
</head>
<ui:includeClientLib categories="cq.shared"></ui:includeClientLib>
<script type="text/javascript">
	var browserLocale = <%='"' +  xssAPI.encodeForJSString(getBrowserLocale(request)) + '"'%>;
	CQ.I18n.setLocale(browserLocale);
	var contextRoot =  "<%= request.getContextPath() %>";
	var urlParametersObject = {};   //Save parameters in case POST request is submitted to render Letter.
	urlParametersObject["<%= UIHelper.URLPARAM_LETTERID%>"] =  <%= getParameterValue(request,UIHelper.URLPARAM_LETTERID, xssAPI)%>;
	urlParametersObject["<%= UIHelper.URLPARAM_LETTERNAME%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_LETTERNAME, xssAPI) %>;
	urlParametersObject["<%= UIHelper.URLPARAM_LETTERINSTANCEID%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_LETTERINSTANCEID, xssAPI) %>;
	urlParametersObject["documentId"] = <%= getParameterValue(request, "documentId", xssAPI) %>;
	urlParametersObject["draftId"] = <%= getParameterValue(request, "draftId", xssAPI) %>;
	urlParametersObject["<%= UIHelper.URLPARAM_DATAURL%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_DATAURL, xssAPI) %>;
	if(urlParametersObject["documentId"]||urlParametersObject["draftId"] || urlParametersObject["<%= UIHelper.URLPARAM_LETTERID%>"] || urlParametersObject["<%= UIHelper.URLPARAM_LETTERNAME%>"] || urlParametersObject["<%= UIHelper.URLPARAM_LETTERINSTANCEID%>"] || urlParametersObject["<%= UIHelper.URLPARAM_DATAURL%>"]) {
		urlParametersObject["<%= UIHelper.URLPARAM_LETTERVERSION%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_LETTERVERSION, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_LETTERPUBLISHDATE%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_LETTERPUBLISHDATE, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_USETESTDATA%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_USETESTDATA, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_USELATEST%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_USELATEST, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_DATA%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_DATA, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_DATAURL%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_DATAURL, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_PREVIEW%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_PREVIEW, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_LC_WORKSPACE%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_LC_WORKSPACE, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_FBDEBUG%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_FBDEBUG, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_DEBUG%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_DEBUG, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_DATADEBUG%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_DATADEBUG, xssAPI) %>;
		urlParametersObject["<%= UIHelper.URLPARAM_APPNAME%>"] = <%= getParameterValue(request, UIHelper.URLPARAM_APPNAME, xssAPI) %>;
		urlParametersObject["dataRef"] = <%= getParameterValue(request, "dataRef", xssAPI) %>;
		urlParametersObject["debugDirectory"] = <%= getParameterValue(request, "debugDirectory", xssAPI) %>;
		urlParametersObject["<%= DBConstants.PREFILL_SERVICE_PARAMS %>"] = <%= getParamMapLocation(request, sling, xssAPI) %>;
	} else {
		urlParametersObject = null;
	}
</script>
<cq:setContentBundle source="request"/>

	<%
		Resource container = resource.getChild("templates");
		if (container != null) {
             Iterable<Resource> templates = container.getChildren();
              for(Resource template : templates){
                    ValueMap valueMap = template.adaptTo(ValueMap.class);
                    String resourceType = (String) valueMap.get("sling:resourceType");
                    String templateId = (String) valueMap.get("templateId");
                    Boolean wrapContent = (Boolean)valueMap.get("wrapContent", false);
                    if(wrapContent) { %>
        <script id="<%= xssAPI.encodeForHTMLAttr(templateId) %>" type="text/ng-template"><div><sling:include resourceType="<%= xssAPI.encodeForHTMLAttr(resourceType) %>"/></div></script>
                    <% } else { %>
        <script id="<%= xssAPI.encodeForHTMLAttr(templateId) %>" type="text/ng-template"><sling:include resourceType="<%= xssAPI.encodeForHTMLAttr(resourceType) %>" /></script>
                    <% } %>
	        <% }
        } %>
	<body id="formBody" style="-webkit-touch-callout: none;-webkit-user-select: none;-khtml-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none; overflow: hidden">

		<div class="container-fluid">
			<% if( !( ("\"1\"").equals(getParameterValue(request, UIHelper.URLPARAM_LC_WORKSPACE))) ){%>
				<div class="row">
					<div class="col-sm-12 col-md-12 col1"> <span><i class="logo" alt="" ></i></span><span>Adobe Experience Manager - Correspondence Management</span></div>
				</div>
			<% } %>
			<div safe-ng-view ></div>
		</div>
	</body>
    <!--Including locale based dictionary for Picture Clause-->
    <ui:includeClientLib categories="<%=categories%>" ></ui:includeClientLib>
    <!--Including noConflict to avoid loading of jquery from xfaforms-->
    <ui:includeClientLib categories="form.noConflict" ></ui:includeClientLib>
	<!-- Including EXM Building block -->
	<ui:includeClientLib categories="cq.gui.ccr.admin" ></ui:includeClientLib>
	<ui:includeClientLib categories="cq.gui.ccr.ccr_ui" ></ui:includeClientLib>
</html>
