<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div ng-controller="ContentLibraryCtrl" class="contentLibrary">

    <nav class="navbar navbar-default">
        <div class="navbar-header">
            <p class="navbar-text">{{::I18n.getMessage("CONTENT LIBRARY")}}</p>
        </div>
        <div class="form-group navbar-right content-Library-CloseBtn">
            <button type="button" class="btn" ng-click="closeClickHandler()">X</button>
        </div>
    </nav>
    <nav class="navbar navbar-default">
        <div class="collapse navbar-collapse" >
            <form class="navbar-form" role="search">
                <div class="navbar-header">
                    <button type="button" class="btn btn-primary" ng-disabled="!insertEnable" ng-click="insertClickHandler()">{{::I18n.getMessage("Insert")}}</button>
                </div>
                <div class="btn-group assetTypes" role="group" ng-click="updateList()" ng-show="!isAttachmentView">
                    <button type="button" class="btn btn-default" title="Filter for text assets" ng-model="showText"  btn-checkbox><i class="asset-text-icon"></i></button>
                    <button type="button" class="btn btn-default" title="Filter for image assets" ng-model="showImage"  btn-checkbox><i class="asset-image-icon"></i></button>
                    <button type="button" class="btn btn-default" title="Filter for condition assets" ng-model="showCondition"  btn-checkbox><i class="asset-condition-icon"></i></button>
                    <button type="button" class="btn btn-default" title="Filter for list assets" ng-model="showList"  btn-checkbox><i class="asset-list-icon"></i></button>
                </div>
                <div  class="navbar-right">
                    <div class="form-group">
                        <input type="text" class="form-control" ng-model="fullText" ng-keyup="fullTextSearch($event)"  placeholder="Search">
                    </div>
                    <button type="button" class="btn btn-default"  ng-click="updateList()">{{::I18n.getMessage("Search")}}</button>
                </div>
            </form>
        </div>
    </nav>
    <div class="table-responsive">
        <table id="contentLibrary" class="table table-condensed contentLibraryTable-breakWord excludeScrollbar table-bordered">
            <thead>
            <tr>
                <th class="col-lg-4 col-md-4 col-sm-4">{{::I18n.getMessage("Name")}}</th>
                <th class="col-lg-4 col-md-4 col-sm-4">{{::I18n.getMessage("Description")}}</th>
                <th class="col-lg-4 col-md-4 col-sm-4">{{::I18n.getMessage("Updated By")}}</th>
            </tr>
            </thead>
        </table>
        <div class="contentLibraryTableBody">
            <table class="table table-condensed contentLibraryTable-breakWord table-bordered">
                <tbody class="contentLibraryBody">
                <tr ng-repeat="data in dataProvider" class="{{data.active}}" ng-click="moduleClickHandler(data)" ng-dblclick="moduleDblClickHandler(data)">
                    <td class="col-lg-4 col-md-4 col-sm-4 contentLibrary-row-breakWord">{{data.title}}</td>
                    <td class="col-lg-4 col-md-4 col-sm-4 contentLibrary-row-breakWord">{{data.desc}}</td>
                    <td class="col-lg-4 col-md-4 col-sm-4 contentLibrary-row-breakWord">{{data.lastUpdatedBy}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <!--<nav class="navbar navbar-default">
        <div class="form-group navbar-right">
            <button type="button" class="btn btn-default" ng-click="closeClickHandler()">{{I18n.getMessage("Close")}}</button>
        </div>
    </nav>  -->
</div>
