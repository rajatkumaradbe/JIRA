<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="modal-header">
    <h3>{{::I18n.getMessage("Open Letter")}}</h3>
</div>
<div class="modal-body">
    <form class="form-horizontal">
        <div class="btn-group">
            <button type="button" class="btn btn-primary" ng-model="letterType" btn-radio="'LetterId'">{{::I18n.getMessage("Letter Id")}}</button>
            <button type="button" class="btn btn-primary" ng-model="letterType" btn-radio="'LetterName'">{{::I18n.getMessage("Letter Name")}}</button>
            <button type="button" class="btn btn-primary" ng-model="letterType" btn-radio="'LetterInstance'">{{::I18n.getMessage("Letter Instance")}}</button>
        </div>
        <div class="control-group" ng-show="letterType == 'LetterId'">
            <label class="control-label" >{{::I18n.getMessage("Letter Id")}}</label>
            <div class="controls">
                <select ng-model="selectedLetter"  ng-options="letter.id for letter in letters">
                    <option value="">-- {{::I18n.getMessage("choose letter id")}} --</option>
                </select>
            </div>
        </div>
        <div class="control-group" ng-show="letterType == 'LetterName'">
            <label class="control-label" >{{::I18n.getMessage("Letter Name")}}</label>
            <div class="controls">
                <select ng-model="selectedLetter"  ng-options="letter.name for letter in letters">
                    <option value="">-- {{::I18n.getMessage("choose letter name")}} --</option>
                </select>
            </div>
        </div>
        <div class="control-group" ng-if="letterType == 'LetterInstance'">
            <label class="control-label" >{{::I18n.getMessage("Letter Instance")}}</label>
            <div class="controls">
                <input type="text" ng-model="invokeParam.letterInstanceId"  placeholder="Letter Instance id">
            </div>
        </div>
        <div class="btn-group" >
            <button type="button" class="btn btn-primary" ng-model="dataType" btn-radio="'DataURL'">{{::I18n.getMessage("Data URL")}}</button>
            <button type="button" class="btn btn-primary" ng-model="dataType" btn-radio="'SampleData'">{{::I18n.getMessage("Sample Data")}}</button>
            <button type="button" class="btn btn-primary" ng-model="dataType" btn-radio="'TestData'">{{::I18n.getMessage("Test Data")}}</button>
        </div>
        <div class="control-group" ng-if="dataType == 'DataURL'">
            <label class="control-label" >{{::I18n.getMessage("Data URL")}}</label>
            <div class="controls">
                <input type="text" ng-model="invokeParam.dataUrl"  placeholder="data url" >
            </div>
        </div>
        <div class="control-group" ng-if="dataType == 'SampleData'">
            <label class="control-label" >{{::I18n.getMessage("Sample Data")}}</label>
            <div class="controls">
                <textarea ng-model="data" ng-model="invokeParam.xmlData" ></textarea>
            </div>
        </div>
        <div class="control-group" ng-if="dataType == 'TestData'">
            <label class="control-label" ng-model="invokeParam.useTestData" >{{::I18n.getMessage("Using Test Data")}}</label>
        </div>
        <div class="control-group" >
            <label class="control-label" >{{::I18n.getMessage("Publish Date")}}</label>
            <div class="controls">
                <input type="text" ng-model="data.value" />
                <button class="btn" ng-click="showDatePopup = !showDatePopup" ng-init="invokeParam.letterPublishDate" type="button"><i class="icon-blankLine"></i></button>
                <datepicker ng-show="showDatePopup" ng-model="data.value" show-weeks="false"></datepicker>
            </div>
        </div>
        <div class="control-group">
            <label class="control-label" >{{::I18n.getMessage("Options")}}</label>
            <div class="controls">
                <label class="checkbox"> <input type="checkbox" ng-model="invokeParam.preview">{{::I18n.getMessage("Preview")}} </label>
                <label class="checkbox"><input type="checkbox" ng-model="invokeParam.useLatest">{{::I18n.getMessage("Use Latest")}}</label>
            </div>
        </div>
    </form>
</div>
<div class="modal-footer">
    <button class="btn btn-warning cancel" ng-click="previewLetter(selectedLetter)" >{{::I18n.getMessage("Preview")}}</button>
    <button class="btn btn-warning cancel" ng-click="closeLetterOptionDialog()">{{::I18n.getMessage("Cancel")}}</button>
</div>