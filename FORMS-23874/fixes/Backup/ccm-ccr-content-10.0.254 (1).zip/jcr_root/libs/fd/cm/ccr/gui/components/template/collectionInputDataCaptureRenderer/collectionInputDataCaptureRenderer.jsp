<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div ng-controller="CollectionInputDataCaptureRendererCtrl" class="collectionInput" >
    <label>{{::data.labelField }}</label>
    <input data-somExp="{{::data.formSomExp}}" type="text" aria-label="{{::data.labelField}}" ng-focus="focusInHandler()" ng-blur="focusOutHandler()" ng-model="value" disabled readonly title="{{::data.toolTip}}">
    <button class="btn btn-default" ng-click="hideShow()"><i class="glyphicon " ng-class="{'glyphicon-triangle-right':!open,'glyphicon-triangle-bottom':open}" ></i></button>
    <div ng-show="open" ng-repeat="data in collectionInstanceDataProvider">
        <div ng-include src="itemRendererFunction(data)"></div>
    </div>
    <span class="help-block" ng-show="!open">{{ data.collDataTypeError }}</span>
<div>