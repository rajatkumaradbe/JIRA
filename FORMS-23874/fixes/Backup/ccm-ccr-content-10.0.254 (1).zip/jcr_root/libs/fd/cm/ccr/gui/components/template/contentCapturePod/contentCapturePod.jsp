<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="contentCapturePod" ng-controller="ContentCapturePodCtrl">
    <div class="actionButtons_search" >
        <div class="actionBtns" ng-controller="ToolBarCtrl">
            <div class="btn-group">
                <button class="btn-link btn" ng-disabled="!moveUpEnabled" ng-click="moveUpClickHandler()" title="{{::I18n.getMessage('Move the selected content up.')}}"><i class="actUp"></i></button>
                <button class="btn-link btn" ng-disabled="!moveDownEnabled" ng-click="moveDownClickHandler()" class="" title="{{::I18n.getMessage('Move the selected content down.')}}"><i class="actDown"></i></button>
            </div>
            <button class="btn-link btn" ng-disabled="!deleteEnabled" ng-click="deleteClickHandler()" class="" title="{{::I18n.getMessage('Delete the selected content..')}}"><i class="actRmv"></i></button>
            <div class="btn-group">
                <button class="btn-link btn" ng-disabled="!leftIndentEnabled" ng-click="rightIndentClickHandler()" class="" title="{{::I18n.getMessage('Increase indentation of selected content.')}}"><i class="actIndI"></i></button>
                <button class="btn-link btn" ng-disabled="!rightIndentEnabled" ng-click="leftIndentClickHandler()" class="" title="{{::I18n.getMessage('Decrease indentation of selected content.')}}"><i class="actIndD"></i></button>
            </div>
            <div class="btn-group">
                <button class="btn-link btn" ng-disabled="!pageBreakBeforeEnabled" ng-click="applyPageBreak(true)" title="{{::I18n.getMessage('Insert page Break before selected module.')}}"><i class="actPageBB"></i></button>
                <button class="btn-link btn" ng-disabled="!pageBreakAfterEnabled" ng-click="applyPageBreak(false)" title="{{::I18n.getMessage('Insert page Break after selected module.')}}"><i class="actPageBA"></i></button>
            </div>
        </div>
    </div>
    <div class="actionButtons_topLevel" ng-controller="ToolBarCtrl" >
        <div class="actionBtns" >
            <div class="btn-group">
                <button class="btn-link btn" ng-click="expandCollapseHandler(true)" title="{{::I18n.getMessage('Expand All')}}"><i class="expandAll"></i></button>
                <button class="btn-link btn" ng-click="expandCollapseHandler(false)" title="{{::I18n.getMessage('Collapse All')}}"><i class="collapseAll"></i></button>
            </div>
            <div class="input-group searchBox">
                <input id="searchInput" type="search" ng-minlength="2" ng-model="searchInput" ng-enter="findAndHighlightTargetAreaAndModule(searchInput)" class="form-control ng-pristine ng-valid" title="{{::I18n.getMessage('find by name')}}" placeholder="{{::I18n.getMessage('Find')}}">
                <span class="searchclear close" title="{{::I18n.getMessage('close')}}" ng-click="searchInput='';findAndHighlightTargetAreaAndModule('')" ng-show="searchInput.length != 0"></span>
            </div>
        </div>
        <div class="searchResultContainer" ng-show="searchResult.length != 0">
            <div class="searchResultInfo">
                <span class="searchResult" title="{{searchResult}}" >{{searchResult}}</span>
            </div>
            <div class="btn-group">
                <button class="btn-link btn" ng-click="highlightFoundItem(false)" title="{{::I18n.getMessage('previous')}}" ><i class="previous-Icon"></i></button>
                <button class="btn-link btn" ng-click="highlightFoundItem(true)" title="{{::I18n.getMessage('next')}}"><i class="next-Icon"></i></button>
            </div>
        </div>
    </div>
    <div  class="tree content-tab">
        <ul class="contentTree">
            <li ng-repeat="target in targetInstanceList" on-finish-render="ngRepeatFinished" class="targetArea">
             <article data-hierarchypath="{{::target.hierarchyPath}}" ng-click="onTargetSelectionChange(target)" tabindex="0">
                 <p class="actBtn_desc truncate-overflown-text">
                    <i class="rightArrow-icon"></i>
                     <i class="icon-info" ng-show="target.compareInfo" title={{::target.compareInfo}}></i>
                    <label title="{{::target.localizedName}}">{{::target.localizedName}}</label>
                 </p>
                 <p class="actBtns">
                    <button title="{{::I18n.getMessage('Insert inline text')}}" ng-class="{'vHidden' : !target.freeTextAllowed}" ng-click="onInsertFreeTextClick(target);$event.stopPropagation();" class="btn-link btn"><i class="text-icon" ></i></button>
                    <button title="{{::I18n.getMessage('Insert blank line')}}" ng-click="insertBlankLine(target);$event.stopPropagation();" class="btn-link btn" ><i class="newLine-icon" ></i></button>
                    <span><i class="vHidden"></i></span>
                    <span><i class="vHidden"></i></span>
                     <span><i class="vHidden"></i></span>
                    <span title="{{::I18n.getMessage('Per letter design, you cannot reorder the content in this focus area or list.')}}" class="btn-link btn" ng-class="{'vHidden' : !target.orderLocked}"><i class="lock-icon"></i></span>
                    <span title="{{target.unfilledVariableCount}} {{::I18n.getMessage('unfilled variable')}}" class="btn-link btn">&nbsp;{{target.unfilledVariableCount}}&nbsp;</span>
                 </p>
             </article>
                <ul class="subArea">
                    <li ng-repeat="data in target.targetContentArray" ng-include src="MODULE_INSTANCE_RENDERER" class="subModuleLI" ></li>
                </ul>
            </li>
         </ul>
    </div>
    <!--<accordion close-others="false">
        <accordion-group  class="targetInstance"  heading="{{target.localizedName}}" ng-repeat="target in targetInstanceList"  >
            <icc-list change="onTargetSelectionChange(index,item)" data-provider="target.targetContentArray" item-renderer="{{MODULE_INSTANCE_RENDERER}}"></icc-list>
        </accordion-group>
    </accordion>-->
</div>