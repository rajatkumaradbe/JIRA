<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div ng-controller="DataCapturePodCtrl">
    <div class="dataCapturePod dataFields"  >
        <form>
            <span id="filterByLabel">{{::I18n.getMessage("Filter By:")}}</span>
            <div class="checkbox">
                <label>
                    <input type="checkbox" aria-labelledby="filterByLabel" ng-click="includeFilter('error')">
                    {{::I18n.getMessage("Errors")}}</label>
            </div>
        </form>
    </div>
    <div class="formDataFields" title="{{dataCaptureDataProvider.length}}">
        <div ng-repeat="data in dataCaptureDataProvider | filter:dataFilter">
            <div ng-include src="itemRendererFunction(data)"></div>
        </div>
    </div>
</div>
