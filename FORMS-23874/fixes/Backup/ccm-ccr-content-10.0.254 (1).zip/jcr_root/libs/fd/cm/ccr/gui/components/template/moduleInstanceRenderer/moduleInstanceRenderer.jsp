
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<article data-path="{{::data.id}}" data-hierarchypath="{{::data.hierarchyPath}}" ng-controller="ModuleInstanceCtrl" ng-dblclick="moduleClickHandler(data,$index,true);$event.stopImmediatepropagation()" ng-click="moduleClickHandler(data,$index,null,$event); $event.stopImmediatepropagation()" ng-class="{moduleInstanceSelected : data.userSelected, moduleInstanceItem : true}" tabindex="0">
         <p class="actBtn_desc">
            <i ng-class="{'vHidden' : !data.isListModule && !data.isConditionModule}" class="rightArrow-icon"></i>
             <i ng-show="data.compareInfo" title={{::data.compareInfo}} class="icon-info"></i>
             <i ng-class="data.iconStyle"></i>
            <label class="truncate-overflown-text" ng-class="{'errorStyle': data.hasError}" title="{{ data.errorMsg ? data.errorMsg : data.displayName }}">{{ ::data.displayName }}</label>
             <label ng-show="data.isListModule && (data.min !=0 || data.max != POSITIVE_INFINITY)">&nbsp;{{::data.min}}/{{::data.maxNotation}}&nbsp;</label>
             <span class="defaultVisibility" ng-show="(data.userSelected && data.isTextModule && !data.selected && ccrSearchShow)">{{::I18n.get('To view the search results in this datamodule, click the eye icon to select it.')}}</span>
         </p>
         <p class="actBtns">
             <span ng-class="{'vHidden' : !(data.hasDisplayVariables || data.open)}">
                <button title="{{::I18n.getMessage('Open/Close content variable')}}" ng-click="showDataCapturePod();$event.stopPropagation();" ng-show="data.hasDisplayVariables" class="btn-link btn" tabindex="{{data.userSelected ? '0' : '-1'}}"><i class="formFields-icon"></i> </button>
                <button title="{{::I18n.getMessage('The letter design permits you to add content from the Content Library.')}}" ng-click="showContentLibrary();$event.stopPropagation();" ng-show="data.open" class="btn-link btn" tabindex="{{data.userSelected ? '0' : '-1'}}"><i class="library-icon"></i></button>
             </span>
             <span ng-class="{'vHidden' : !(data.isListModule || (data.isTextModule && data.editable)) }">
                <button title="{{::I18n.getMessage('Edit selected content.')}}" ng-click="showTextEditor();" ng-show="data.isTextModule && data.editable" class="btn-link btn" tabindex="{{data.userSelected ? '0' : '-1'}}"><i class="edit-icon"></i></button>
                 <button title="{{::I18n.getMessage('Insert blank line')}}" ng-click="insertBlankLine(data);$event.stopPropagation();" ng-show="data.isListModule" class="btn-link btn" tabindex="{{data.userSelected ? '0' : '-1'}}"><i class="newLine-icon"></i></button>
             </span>
            <button title="{{::I18n.getMessage('Select to add content to the letter')}}" ng-disabled="data.isConditionChildren || !data.isOptional" ng-click="data.selected = !data.selected;$event.stopPropagation();" class="btn-link btn" tabindex="{{data.userSelected ? '0' : '-1'}}">
                <i ng-class="{'eye-icon':data.selected,'no-view-icon':!data.selected}" ></i>
            </button>
             <button title="{{::I18n.getMessage('Select to skip Bullets/Numbering for the module')}}" ng-class="{'vHidden' : !(data.isListModule || data.isListChildren)}" ng-click="data.skipStyle = !data.skipStyle;$event.stopPropagation();" class="btn-link btn" tabindex="{{data.userSelected ? '0' : '-1'}}">
                 <i ng-class="{'subList-icon':data.skipStyle,'subList-disable-icon':!data.skipStyle}" ></i>
             </button>
            <span title="{{::I18n.getMessage('Open List setting Pop-up')}}" ng-click="launchNestedListSetting(data);$event.stopPropagation();" ng-class="{'vHidden' : !(data.isListModule && data.isListChildren)}" class="btn-link btn"><i class="listindent-icon"></i></span>
            <span title="{{::I18n.getMessage('Per letter design, you cannot reorder the content in this focus area or list.')}}" ng-class="{'vHidden' : !(data.isListModule && data.orderLocked)}" class="btn-link btn"><i class="lock-icon"></i></span>

            <span class="btn-link btn" title="{{target.unfilledVariableCount}} {{::I18n.getMessage('unfilled variable')}}">&nbsp;{{ data.unfilledVariableCount }}&nbsp;</span>
         </p>
    </article>
    <div ng-show="data.showDataCapture" class="jumbotron formDataFields"  >
        <div ng-repeat="data in data.displayVariables track by $index" ng-controller="DataCapturePodCtrl">
            <div ng-include src="itemRendererFunction(data)"></div>
        </div>
    </div>
    <ul ng-if="data.contents.length>0" class="subArea">
        <li ng-repeat="data in data.contents.toArray()" ng-include src="MODULE_INSTANCE_RENDERER" class="subModuleLI"></li>
    </ul>
    <p class="emptyPTag"></p>      <!--To avoid extra li item height if no ul item is present in li -->
