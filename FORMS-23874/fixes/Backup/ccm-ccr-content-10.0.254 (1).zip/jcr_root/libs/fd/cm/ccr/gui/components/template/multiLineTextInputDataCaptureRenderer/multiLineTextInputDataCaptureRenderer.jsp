<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div>
    <label>{{::data.labelField }}</label>
    <textarea class = "textAreaResize" data-somExp="{{::data.formSomExp}}" ng-model="data.value" title="{{::data.toolTip}}" ng-class="{ngInvalid : !data.dataTypeValid}" ng-disabled="{{::!data.editable}}" ng-trim="false"  ng-focus="focusInHandler()" ng-blur="focusOutHandler()" ></textarea>
    <span class="help-block">{{ data.dataTypeError }}</span>
    <script>
        // Check IE version
        if(ObjectUtil.isIE()) {
            // Set resizeable property
            $(".textAreaResize").resizable();
        }
    </script>
</div>