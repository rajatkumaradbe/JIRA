<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="row">
    <div class="ccr-alert alert alert-info"  role="alert" >
        <label class="ccr-alert-msg"></label>
        <button type="button" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
    <div class="col-sm-6 col-md-6 col2 ccr-letter-toolbar-title-container">
        <h2 class="heading letterName truncate-overflown-text" title="{{::letterTitle}}">{{::letterTitle}} <span id="letterInstanceName"></span></h2>
    </div>
    <div class="col-sm-6 col-md-6 col2 ccr-letter-toolbar-actions-container">
        <ul class="saveOptions">
            <li ng-include src="ExtensionActionBarTemplateURL" ></li>
        </ul>
    </div>
</div>
<div class="row letterPreviewDiv" ng-show="showLetterPreview">
    <img class="previewLoader" ng-show="!pdfLoaded">
    <iframe class="cm-manageassets-emptyIframe" ng-show="showEmptyIframe" width="100%" height="100%"></iframe>
    <iframe iframe-onload="pdfPreviewLoaded()" ng-init="pdfLoaded = false;" ng-src="{{letterPreviewIframeSrc}}" ng-show="pdfLoaded && !showEmptyIframe" width="100%" height="100%" role="presentation"></iframe>
</div>
<div class="row">
    <div class="col-sm-7 col-md-5 col3 transparentDiv" ng-show="showContentLibrary"></div>
    <div class="col-sm-7 col-md-5 col3 nopadding" ng-show="isBusy" ></div>
    <div class="col-sm-7 col-md-5 col3 nopadding" ng-show="showLetterDetails && !isBusy" >
        <ul id="tabs" >
            <li ng-repeat="tab in tabDataProvider" class="{{tab.active}}" title="{{::tab.label}}">
                <a  href="" ng-click="tabClickHandler(tab)" aria-current="{{tab.active ? 'page' : null}}"><span class="{{tab.value.toLowerCase()}}-icon"></span>{{::tab.label}}</a>
                <sup ng-show="tab.value.toLowerCase() == 'data' && getTabCount(tab) != '0'" class="{{tab.value.toLowerCase()}}-sup badge">{{getTabCount(tab)}}</sup>
            </li>
        </ul>
        <div ng-show="selectedType == 'Data'" class="dataCapturePodContainer" ng-include src="DataCapturePodTemplateURL"></div>
        <div ng-show="selectedType == 'Content'" ng-include src="ContentCapturePodTemplateURL"></div>
        <div ng-show="selectedType == 'Attachment'" ng-include src="AttachmentPodTemplateURL"></div>
    </div>
    <div class="col-sm-7 col-md-5 col3" id="divContainingTextEditor" ng-model="textEditorContent" ng-show="showTextEditor">
        <div ng-include src="TextEditorTemplateURL"></div>
    </div>
    <div class="col-sm-5 col-md-7 col4" id="divContainingIFrame" ng-style="showPDF" ng-hide="!isRenditionTypePDF">
        <iframe id="pdfIFrame" src="" width="100%" height="100%"></iframe>
    </div>
    <div class="col-sm-5 col-md-7 col4" id="divContainingMFIFrame" ng-hide="showContentLibrary">
        <div class="toolbarheader" role="toolbar">
            <div class="btn-group" data-toggle="buttons-checkbox">
                <button class="highlightLHSAction btn btn-default active" ng-click="updateEnablePDFCCRHighlight()" type="button" name="bold" title="{{::I18n.getMessage('Highlight selected modules in content')}}">
                    <i class="highlightLHS-icon"></i>
                </button>
                <button class="highlightEditableModuleAction btn btn-default" ng-click="highlightEditableModules(true)" type="button" name="bold" title="{{::I18n.getMessage('Highlight editable sections')}}">
                    <i class="highlightEditable-icon"></i>
                </button>
            </div>
        </div>
        <iframe id="mobileFormIFrame" src="" width="100%" height="100%" role="presentation"></iframe>
    </div>
    <div class="col-sm-5 col-md-7 col4 " ng-include src="ContentLibraryTemplateURL" ng-show="showContentLibrary"></div>
    </div>
</div>
<div ng-include src="NestedListSettingTemplateURL"></div>
<div ng-include src="InsertFreeTextDialogTemplateURL"></div>
<div ng-include src="LetterInstanceDetailsDialogURL"></div>
