<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div>
  <label>{{::data.labelField }}</label>
  <input data-somExp="{{::data.formSomExp}}" 
          aria-label="{{::data.labelField}}" 
          type="checkbox" 
          ng-checked="data.value === true || data.value === 'true' || data.value === '1'"
          ng-click="data.value = (data.value === true || data.value === 'true' || data.value === '1') ? '0' : '1'; 
                  data._edited = true; 
                  FormBridgeServiceDelegate.instance.pdfSetFieldValue(data.formSomExp, data.value, 'BOOLEAN');"
          title="{{::data.toolTip}}" 
          ng-disabled="{{::!data.editable}}" 
          ng-blur="focusOutHandler()" 
          ng-focus="focusInHandler()">
  <span class="help-block">{{ data.dataTypeError }}</span>
<div>