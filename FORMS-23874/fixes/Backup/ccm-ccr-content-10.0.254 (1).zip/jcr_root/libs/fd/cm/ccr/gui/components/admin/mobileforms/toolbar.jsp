<%--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2013 Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--%>
<%
%><%@taglib prefix="sling" uri="http://sling.apache.org/taglibs/sling/1.0"%><%
%><sling:defineObjects/><%
%>
<%@ page import="com.adobe.forms.service.LCFormsOptionService,
                                       com.adobe.forms.external.utils.LocalizationUtils,
                                       com.day.cq.i18n.I18n" %>
<%
    I18n i18n = LocalizationUtils.getFirstLocaleFromRequest(slingRequest);
%>

<div class="toolbarheader" style="display:inline-block;width:100%" role="toolbar">
    <div class="toggle">
        <label title="<%=i18n.get("Highlight selected modules in content")%>"><input type="checkbox" name="toggle" checked><span><span class="highlightLHSAction"></span></span></label>
        <label title="<%=i18n.get("Highlight editable modules")%>"><input type="checkbox" name="toggle"><span><span class="highlightEditableModuleAction"></span></span></label>
        <select id="editableColor">
            <option value="#f2f2f2">#f2f2f2 (suggest by Rahul)</option>
            <option value="#d2e6f5">#d2e6f5 (suggest by Rahul)</option>
            <option value="#fffde6">#fffde6 (suggest by Rahul)</option>
            <option value="#ffeadc">#ffeadc (suggest by Rahul)</option>
            <option value="#DEE3FF">#DEE3FF (PDF highlight editable Fields)</option>
            <option value="#E1E1E1">#E1E1E1 (making gray bit darker)</option>

        </select>
    </div>
    <script>
        (function()    {
            if(!window.formBridge._isBrowserCompatible()) {
                setTimeout(function(){
                    $("#toolbartextinternal").text("This form may not render correctly as you are using an unsupported browser.");
                }, 500);
            }
            var apply = false;
            $(".highlightEditableModuleAction").click(function(){
                apply = !apply
                if(apply)
                    $("div[data-editable='true']").css("background-color",$( "#editableColor option:selected" ).val());
                else
                    $("div[data-editable='true']").css("background-color","");
            });
            $("#editableColor").change(function(){
                if(apply)
                    $("div[data-editable='true']").css("background-color",this.value);
            });
        } )();
    </script>
</div>
