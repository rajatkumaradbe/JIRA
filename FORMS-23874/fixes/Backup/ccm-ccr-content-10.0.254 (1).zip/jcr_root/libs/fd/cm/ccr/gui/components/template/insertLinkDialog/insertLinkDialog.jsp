<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div>
	<div class="modal-header" >
	    <h3>{{::I18n.getMessage("Insert Link")}}</h3>
	</div>
	<div class="modal-body">
		 <div>
            <label class="control-label" >{{::I18n.getMessage("Link Text")}}</label>
            <input type="text" ng-model="link.text" ng-change="enableOkButton()">
          </div>
          <div>
			  <label class="control-label" >{{::I18n.getMessage("Link Url")}}</label>
			  <input type="url" ng-model="link.url" ng-change="enableOkButton()">
          </div>
	</div>
	<div class="modal-footer">
	    <button class="btn btn-warning cancel" ng-disabled="link.state" ng-click="processOk()">{{::I18n.getMessage("Ok")}}</button>
	    <button class="btn btn-warning cancel" ng-click="processCancel()">{{::I18n.getMessage("Cancel")}}</button>
	</div>
</div>