
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<%@include file="/libs/granite/ui/global.jsp" %>
<%@taglib prefix="cq" uri="http://www.day.com/taglibs/cq/1.0" %>
<%@page import="com.day.cq.i18n.I18n" %>
<%@page import="java.util.*" %>
<%@page import="org.apache.commons.lang3.StringUtils" %>
<%@ page import="com.adobe.fd.df.fdinternal.util.UIHelper" %>
<%@ page import="com.adobe.fd.df.fdinternal.model.TextEditorConfig" %>
<%@ page import="com.adobe.fd.df.fdinternal.model.ElementConfiguration, com.adobe.granite.ui.components.Config, com.adobe.granite.ui.components.ds.DataSource" %>
<%
TextEditorConfig textEditorConfig = UIHelper.getTextEditorConfiguration();
ElementConfiguration elementConfiguration;
%>

<div class="textEditor" id="textEditorMain" data-cssPath="<%= textEditorConfig.getCSSPaths() %>">
<nav class="navbar texteditor-moduleName" unselectable="off" >
    <div class="container-fluid">
        <ul class="nav navbar-nav navbar-left">
            <li class="truncate-overflown-text">
                <span class="textModulePath"></span>
                <span class="textModuleName"></span>
            </li>
        </ul>
    </div>
</nav>
<div id="textEditor_toolBar_control" class="textEditor_toolBar_control">
<div class="textEditor_toolBar">
    <button data-wysihtml5-command="undo" class="btn ccr-texteditor-actionBar-button" type="button" title="<%= i18n.get("Undo") %>">
        <i class="undo-icon"></i>
        <span><%= i18n.get("Undo")%></span>
    </button>
    <button data-wysihtml5-command="redo" class="btn ccr-texteditor-actionBar-button" type="button" title="<%= i18n.get("Redo") %>">
        <i class="redo-icon"></i>
        <span><%= i18n.get("Redo")%></span>
    </button>
    <div class ="ccrTitleField" title="<%= i18n.get("Insert Link") %>">
        <button id="textEditor_insertLink_control" data-target="#textEditor_insertLink_dialog" class="textEditor_insertLink_control btn ccr-texteditor-actionBar-button" type="button" value="insert_link" data-original-title="<%= i18n.get("Insert Link") %>" >
            <i class="glyphicon glyphicon-link"></i>
            <span><%= i18n.get("Link")%></span>
        </button>
    </div>
    <div class ="ccrTitleField" title="<%= i18n.get("Find & Replace") %>">
        <button id="textEditor_findAndReplace_control" data-target="#textEditor_findAndReplace_dialog" data-wysihtml5-command="findAndReplace" data-wysihtml5-command-statecallbackfn="setFindAndReplaceMessage" class="textEditor_findAndReplace_control btn ccr-texteditor-actionBar-button" type="button" value="search" data-original-title="<%= i18n.get("Find & Replace") %>">
            <i class="glyphicon glyphicon-search"></i>
            <span><%= i18n.get("Find & Replace")%></span>
        </button>
    </div>
    <div class ="ccrTitleField" title="<%= i18n.get("Special Characters") %>">
        <button id="cm-texteditor-specialcharacter-button" data-target="#cm-texteditor-specialcharacter-popover" class = "btn ccr-texteditor-actionBar-button" type="button" data-original-title="<%= i18n.get("Special Characters")%>" >
            <i class="glyphicon glyphicon-asterisk"></i>
            <span><%= i18n.get("Special Characters")%></span>
        </button>
    </div>
</div>
<div class="textEditor_toolBar">
    <div class="textEditor_menu_group" role="tabpanel">
        <ul class="nav nav-tabs" role="tablist" id="paragraph-tabs">
            <li class="active" value="paragraph" title="<%= i18n.get("Paragragh")%>">
                <a href="#paragragh-panel" id="paragragh-tab" name="paragraph" value="paragraph" aria-controls="paragragh-tab" data-toggle="tab" aria-expanded="false">
                    <span class="glyphicon glyphicon-font" aria-hidden="true" value="paragraph"></span>
                    <%= i18n.get("FONT")%>
                </a>
            </li>
            <li value="alignment" title="<%= i18n.get("Alignment")%>">
                <a href="#alignment-panel" id="alignment-tab" name="alignment" value="alignment" aria-controls="alignment-tab" data-toggle="tab" aria-expanded="false">
                    <span class="glyphicon glyphicon-align-justify" value="alignment" aria-hidden="true"></span>
                    <%= i18n.get("PARAGRAPH")%>
                </a>
            </li>
            <li value="listing"  title="<%= i18n.get("Listing")%>">
                <a href="#listing-panel" id="listing-tab" name="listing" value="listing" aria-controls="listing-tab" data-toggle="tab" aria-expanded="false">
                    <span class="glyphicon glyphicon-list" aria-hidden="true" value="listing"></span>
                    <%= i18n.get("LIST")%>
                </a>
            </li>
        </ul>
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane active in" id="paragragh-panel" aria-labelledby="paragragh-tab">
                <div id="textEditor_paragraphControls_container" class="textEditor_paragraphControls">
                    <span class="TextEditorListControl" title="<%= i18n.get("Font") %>">
                    <select id="textEditor_fontFamily_container"
                            class="textEditor_fontFamilyControl form-control" data-wysihtml5-command="fontFamily"
                            data-wysihtml5-command-element="textEditor_fontFamily_container"
                            data-wysihtml5-command-stateCallbackFn="updateListTextEditor" data-wysihtml5-skip="">
                            <option value="" style="display:none"><%= i18n.get("Select")%></option>
                     </select>
                    </span>
                    <span class="TextEditorListControl" title="<%= i18n.get("Font size") %>">
                    <select id="textEditor_fontSize_container"
                            class="textEditor_fontSizeControl form-control" data-wysihtml5-command="fontSize"
                            data-wysihtml5-command-element="textEditor_fontSize_container"
                            data-wysihtml5-command-stateCallbackFn="updateListTextEditor" data-wysihtml5-skip="">
                            <option value="" style="display:none"><%= i18n.get("Select")%></option>
                    </select>
                    </span>
                    <button id="textEditor_color_control" data-wysihtml5-skip="true" data-wysihtml5-command-element="textEditor_color_control" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setColorInputValue" data-wysihtml5-command="foreColor"
                            class="btn btn-default textEditor_color_control"
                            type="button">
                        <i class="glyphicon glyphicon-text-color"></i>
                    </button>
                    <button id="textEditor_bgcolor_control" data-wysihtml5-skip="true" data-wysihtml5-command-element="textEditor_bgcolor_control" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setColorInputValue" data-wysihtml5-command="hiliteColor"
                            class="btn btn-default textEditor_bgcolor_control"
                            type="button">
                        <i class="glyphicon glyphicon-text-color"></i>
                    </button>
                    <div class="btn-group" data-toggle="buttons-checkbox">
                        <button id="textEditor_bold_control" data-wysihtml5-command="bold" data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_bold_control"
                                class="textEditor_bold_control btn btn-default" type="button" name="bold" title="<%= i18n.get("Bold(Ctrl+Alt+B)") %>">
                        <span class="glyphicon glyphicon-bold" aria-hidden="true"></span>
                        </button>
                        <button id="textEditor_italic_control" data-wysihtml5-command="italic" data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_italic_control"
                                class="textEditor_italic_control btn btn-default" type="button" name="italic" title="<%= i18n.get("Italic(Ctrl+Alt+I)") %>">
                        <span class="glyphicon glyphicon-italic" aria-hidden="true"></span>
                        </button>
                        <button id="textEditor_underline_control" data-wysihtml5-command="underline" data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_underline_control"
                                class="textEditor_underline_control btn btn-default" type="button" name="underline" title="<%= i18n.get("Underline(Ctrl+Alt+U)") %>">
                        <span class="underline-icon" aria-hidden="true"></span>
                        </button>
                    </div>
                    <div class="btn-group" data-toggle="buttons-checkbox">
                        <button id="textEditor_superscript_control" data-wysihtml5-command="superScript" data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_superscript_control"
                                class="textEditor_superscript_control btn btn-default" type="button" name="superScript" title="<%= i18n.get("Superscript") %>">
                        <span class="glyphicon glyphicon-superscript" aria-hidden="true"></span>
                        </button>
                        <button id="textEditor_subscript_control" data-wysihtml5-command="subScript" data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_subscript_control"
                                class="textEditor_subscript_control btn btn-default" type="button" name="subScript" title="<%= i18n.get("Subscript") %>">
                        <span class="glyphicon glyphicon-subscript" aria-hidden="true"></span>
                        </button>
                    </div>
                    <span class="label-text-width">
                        <i class="glyphicon glyphicon-text-width"></i>
                    </span>
                    <span class="TextEditorListControl" title="<%= i18n.get("Spacing between characters") %>">
                    <select id="textEditor_letterSpacing_container"
                            class="textEditor_letterSpacing_control form-control" data-wysihtml5-command="letterSpacing"
                            data-wysihtml5-command-element="textEditor_letterSpacing_container"
                            data-wysihtml5-command-stateCallbackFn="updateListTextEditor" data-wysihtml5-skip="">
                            <option value="" style="display:none"><%= i18n.get("Select")%></option>
                    </select>
                    </span>
                    <%
                    if(textEditorConfig.getTags() != null && textEditorConfig.getTags().size() > 0){ %>
                    <span class="TextEditorListControl" title="<%= i18n.get("Paragraph Format") %>">
                    <select id="textEditor_header_container" class="form-control"  data-wysihtml5-command="header" data-wysihtml5-command-statecallbackfn="updateListTextEditor" data-wysihtml5-command-element="textEditor_header_container" data-wysihtml5-skip unselectable="on">
                        <%
                        for (ElementConfiguration elConfig : textEditorConfig.getTags()){
                        %>
                        <option value="<%= elConfig.getValue() %>" data-classes="<%= elConfig.getCompleteClassName() %>" unselectable="on"><%=elConfig.getText() %></option>
                        <%    }
                        %>
                    </select>
                    </span>
                    <%  } %>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="alignment-panel" aria-labelledby="alignment-tab">
                <div id="textEditor_alignmentControls_container" class="textEditor_alignmentControls_container" style="display: none">
                    <div class="btn-group textEditor_menu_group" data-toggle="buttons-checkbox">
                        <button id="textEditor_justifyleft_control" data-wysihtml5-command="justifyLeft" class="btn btn-default" type="radio"
                                data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_justifyleft_control"
                                class="btn btn-default textEditor_paragraph_menu_item" value="justifyLeft" type="button"
                                name="justifyLeft" checked title="<%= i18n.get("Align Left(Ctrl+L)") %>">
                        <span class="glyphicon glyphicon glyphicon-align-left" aria-hidden="true"></span>
                        </button>
                        <button id="textEditor_justifycenter_control" data-wysihtml5-command="justifyCenter" class="btn btn-default " type="button"
                                data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_justifycenter_control"
                                value="justifyCenter" name="justifyCenter" title="<%= i18n.get("Align Center(Ctrl+E)") %>">
                        <span class="glyphicon glyphicon glyphicon-align-center" aria-hidden="true"></span>
                        </button>
                        <button id="textEditor_justifyfull_control" data-wysihtml5-command="justifyFull" class="btn btn-default" type="button"
                                data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_justifyfull_control"
                                value="justifyFull" name="justifyFull" title="<%= i18n.get("Justify(Ctrl+J)") %>">
                        <span class="glyphicon glyphicon glyphicon-align-justify" aria-hidden="true"></span>
                        </button>
                        <button id="textEditor_justifyright_control" data-wysihtml5-command="justifyRight" class="btn btn-default" type="button"
                                data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_justifyright_control"
                                value="justifyRight" name="justifyRight" title="<%= i18n.get("Align Right(Ctrl+R)") %>">
                        <span class="glyphicon glyphicon glyphicon-align-right" aria-hidden="true"></span>
                        </button>
                    </div>
                    <span class="TextEditorListControl" title="<%= i18n.get("Line spacing") %>">
                    <select id="textEditor_lineHeight_container" class="textEditor_lineHeight_control form-control" data-wysihtml5-command="changeLineHeight"
                            data-wysihtml5-command-element="textEditor_lineHeight_container"
                            data-wysihtml5-command-stateCallbackFn="updateListTextEditor" data-wysihtml5-skip="">
                    	<option value="" style="display:none"><%= i18n.get("Select")%></option>
                    </select>
                    </span>
                    <label class="textEditor-margin-label"><%=i18n.get("Margin")%></label>
                    <div class="textEditor-indentation-numberInput">
                        <span><%=i18n.get("Left")%></span>
                        <input id="textEditor_marginLeft_control" class="form-control textEditor_marginLeft_control textEditor_margin"
                           value="0" name="marginLeft" type="number" data-wysihtml5-command="marginLeft" data-wysihtml5-command-stateCallbackFn="updateInputBoxControl"
                           data-wysihtml5-command-element="textEditor_marginLeft_control" unselectable="off" data-wysihtml5-skip min="0" step="any" title="<%= i18n.get("Left Margin") %>">
                    </div>
                    <div class="textEditor-indentation-numberInput">
                        <span><%=i18n.get("Right")%></span>
                        <input id="textEditor_marginRight_control" class="form-control textEditor_marginRight_control textEditor_margin"
                           value="0" name="marginRight" type="number" data-wysihtml5-command="marginRight" data-wysihtml5-command-stateCallbackFn="updateInputBoxControl"
                           data-wysihtml5-command-element="textEditor_marginRight_control" min="0" step="any" unselectable="off" data-wysihtml5-skip title="<%= i18n.get("Right Margin") %>">
                    </div>
                    <div class="textEditor-indentation-numberInput">
                        <span><%=i18n.get("Top")%></span>
                        <input id="textEditor_marginTop_control" class="form-control textEditor_marginTop_control textEditor_margin"
                           value="0" name="marginTop" type="number" data-wysihtml5-command="marginTop" data-wysihtml5-command-stateCallbackFn="updateInputBoxControl"
                           data-wysihtml5-command-element="textEditor_marginTop_control" min="0" step="any" unselectable="off" data-wysihtml5-skip title="<%= i18n.get("Top Margin") %>">
                    </div>
                    <div class="textEditor-indentation-numberInput">
                        <span><%=i18n.get("Bottom")%></span>
                        <input id="textEditor_marginBottom_control" class="form-control textEditor_marginBottom_control textEditor_margin"
                           value="0" name="marginBottom" type="number" data-wysihtml5-command="marginBottom" data-wysihtml5-command-stateCallbackFn="updateInputBoxControl"
                           data-wysihtml5-command-element="textEditor_marginBottom_control" min="0" step="any" unselectable="off" data-wysihtml5-skip title="<%= i18n.get("Bottom Margin") %>">
                    </div>
                    <button id="textEditor_pageBreak_control" class="btn btn-default textEditor_pageBreak_control" type="button" data-toggle="button" data-wysihtml5-command="pageBreak" data-wysihtml5-command-stateCallbackFn="Form.rte.CommandStateCallbacks.setButtonState"
                          data-wysihtml5-command-element="textEditor_pageBreak_control" title="<%= i18n.get("Page Break") %>">
                      <i class="pagebreak-disable-icon"></i>
                    </button>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="listing-panel" aria-labelledby="listing-tab">
                <div id="textEditor_listingControls_container" class="textEditor_alignmentControls_container" style="display: none">
                    <div class="btn-group" id="textEditor_listing_container">
                        <button title="Bulleted List" class="btn btn-default textEditor_listing_container_unordered" type="button" data-value="UnorderedList" data-wysihtml5-command="insertUnorderedList" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-element="textEditor_listing_container_unordered" href="javascript:;" unselectable="on">
                            <i class="textEditor-list-unordered"></i>
                        </button>
                        <button title="Numbered List" class="btn btn-default textEditor_listing_container_ordered" type="button" data-value="Ordered" data-wysihtml5-command="insertOrderedList" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-value="Ordered" data-wysihtml5-command-element="textEditor_listing_container_ordered" href="javascript:;" unselectable="on">
                            <i class="textEditor-list-ordered"></i>
                        </button>
                        <button title="UpperCase Alphabet List" class="btn btn-default textEditor_listing_container_caps_a" type="button" data-value="A" data-wysihtml5-command="insertOrderedList" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-value="A" data-wysihtml5-command-element="textEditor_listing_container_caps_a" href="javascript:;" unselectable="on">
                            <i class="textEditor-list-caps-a"></i>
                        </button>
                        <button title="LowerCase Alphabet List" class="btn btn-default textEditor_listing_container_a" type="button" data-value="a" data-wysihtml5-command="insertOrderedList" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-value="a" data-wysihtml5-command-element="textEditor_listing_container_a" href="javascript:;" unselectable="on">
                            <i class="textEditor-list-a"></i>
                        </button>
                        <button title="UpperCase Roman List" class="btn btn-default textEditor_listing_container_caps_i" type="button" data-value="I" data-wysihtml5-command="insertOrderedList" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-value="I" data-wysihtml5-command-element="textEditor_listing_container_caps_i" href="javascript:;" unselectable="on">
                            <i class="textEditor-list-caps-i"></i>
                        </button>
                        <button title="LowerCase Roman List" class="btn btn-default textEditor_listing_container_i" type="button" data-value="i" data-wysihtml5-command="insertOrderedList" data-wysihtml5-command-statecallbackfn="Form.rte.CommandStateCallbacks.setButtonState" data-wysihtml5-command-value="i" data-wysihtml5-command-element="textEditor_listing_container_i" href="javascript:;" unselectable="on">
                            <i class="textEditor-list-i"></i>
                        </button>
                    </div>
                    <div class="btn-group">
                        <button data-wysihtml5-command="indent" class="btn btn-default" type="button" title="<%= i18n.get("Increase Indent") %>">
                        <i class="glyphicon glyphicon-indent-left"></i>
                        </button>
                        <button data-wysihtml5-command="outdent" class="btn btn-default" type="button" title="<%= i18n.get("Decrease Indent") %>">
                        <i class="glyphicon glyphicon-indent-right"></i>
                        </button>
                    </div>
                    <div class="btn-group list-compound-control">
                        <button class="btn btn-default" type="button" data-value="on" title="<%= i18n.get("List Component") %>">
                        <i class="listCompound-icon"></i>
                        </button>
                        <button class="btn btn-default" type="button" data-value="off" style="display: none" title="<%= i18n.get("List Component") %>">
                        <i class="listCompound-cancel-icon"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div data-wysihtml5-dialog="insertHTML" style="display:none">
    </div>
</div>
</div>
<div unselectable="off" class="textEditorContainer" >
    <textarea id="textarea">
    </textarea>
    <div class="tooltip fade bottom in textEditorTooltip" role="tooltip">
        <div class="tooltip-arrow"></div>
        <div class="tooltip-inner"></div>
    </div>
</div>
</div>
<nav class="navbar navbar-default textEditor_controlBar_container" unselectable="off" >
    <div class="container-fluid">
        <div class="collapse navbar-collapse" id="controlBar-navbar-collapse">
            <ul class="nav navbar-nav navbar-left">
                <li class="showAll-checkbox">
                    <input type="checkbox" id="textEditorShowAllCheck" title="<%= i18n.get("Show All") %>"><%= i18n.get("Show All") %>
                </li>
                <li>
                    <button class="btn btn-default" id="textEditorPrevButton" title="<%= i18n.get("Previous Module")%>">
                    <span class="glyphicon glyphicon-triangle-left"></span>
                    </button>
                </li>
                <li><button class="btn btn-default" id="textEditorNextButton" title="<%= i18n.get("Next Module")%>">
                    <span class="glyphicon glyphicon-triangle-right"></span>
                    </button></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><button class="btn btn-default" id="textEditorSaveButton" title="<%= i18n.get("Save")%>"><%= i18n.get("Save") %>
                    </button></li>
                <li><button class="btn btn-default" id="textEditorSaveNextButton" title="<%= i18n.get("Save & Next")%>"><%= i18n.get("Save & Next") %>
                    </button></li>
                <li><button class="btn btn-default" id="textEditorCancelButton" title="<%= i18n.get("Close")%>"><%= i18n.get("Close") %>
                    </button></li>
            </ul>
        </div>
    </div>
</nav>
<div id="textEditor_insertLink_dialog" class="textEditor_insertLink_dialogContainer">
    <div class="">
        <form id="textEditor_insertLink_form" class="">
            <div class="textEditor_column">
                <input id="textEditor_insertLink_url" type="text" name="url" placeholder="URL" class="form-control" data-wysihtml5-skip>
            </div>

            <div class="textEditor_column">
                <input id="textEditor_insertLink_alt" type="text" name="alt" placeholder="Alt Text" class="form-control" data-wysihtml5-skip>
            </div>
            <div class="textEditor_column">
                <input type="checkbox" name="target" data-type="targetBlank" value="_blank">
                <span>Open in new page</span>
            </div>
            <div class="textEditor_column">
                <button type="button" data-type="cancel" data-target="#textEditor_insertLink_dialog" class="textEditor_popover_close_btn btn btn-default"><i class="glyphicon glyphicon-remove"></i> </button>
            </div>
            <div class="textEditor_column">
                <button type="button" data-type="apply" data-wysihtml5-command="createLink" class="textEditor_popover_close_btn btn btn-default"><i class="glyphicon glyphicon-ok"></i> </button>
            </div>
        </form>
    </div>
</div>
<div id="textEditor_findAndReplace_dialog" class="textEditor_findReplace_dialog">
    <form id="textEditor_findReplace_dialog">
        <div>
            <div class="textEditor_column">
                <input type="text" placeholder="find" name="findText" class="form-control textEditor_findAndReplace_find" data-wysihtml5-command="changeFindText" data-wysihtml5-skip>
                <input type="checkbox" name="matchCase" data-wysihtml5-command="changeMatchCase" data-wysihtml5-skip>
                <span><%= i18n.get("Match case") %></span>
            </div>
        </div>
        <div>
            <div class="textEditor_column">
                <input type="text" placeholder="replace" name="replaceText" class="textEditor_findAndReplace_replace form-control" data-wysihtml5-command="changeReplaceText" data-wysihtml5-skip>
                <input type="checkbox" name="wholeWord" data-wysihtml5-command="changeWholeWord" data-wysihtml5-skip>
                <span><%= i18n.get("Whole word") %></span>
                <input type="checkbox" name="regExp" value="false" data-wysihtml5-command="changeRegExp" data-wysihtml5-skip>
                <span><%= i18n.get("Reg Ex") %></span>
            </div>
        </div>
        <div>
            <div class="textEditor_column">
                <button class="btn" type="button" data-wysihtml5-command="find"><%= i18n.get("Find") %></button>
            </div>
            <div class="textEditor_column">
                <button class="btn" type="button" data-wysihtml5-command="replace"><%= i18n.get("Replace") %></button>
            </div>
            <div class="textEditor_column">
                <button class="btn" type="button" data-wysihtml5-command="replaceAll"><%= i18n.get("Replace all") %></button>
            </div>
        </div>
        <div class="textEditor_findAndReplace_alert_info alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            <strong><%= i18n.get("Info")%></strong>
            <span id="textEditor_findAndReplace_message"></span>
        </div>
    </form>
</div>
<!--
A node can have a single unicode value with single caption.
A node can have a endValue unicode with a starting unicode value with multiple captions.
A node can have a endvalue unicode with a starting unicode value with single caption. All symbols will show that caption.
-->
<%
Resource dataSourceParent = resource.getChild("templates/textEditorContainer");
Iterator<Resource> resources  = cmp.getItemDataSource(dataSourceParent).iterator();
Config	cfg;
%>
<div id="cm-texteditor-specialcharacter-popover">
    <table>
        <tr>
        <%  Resource eachRow;
            ElementConfiguration elConf;
            String value, caption;
            while(resources.hasNext()) {
                eachRow = resources.next();
                cfg = new Config(eachRow);
                for (int col =0; col < 10; col++) {
                    elConf = cfg.get(""+col, ElementConfiguration.class);
                    if(elConf != null) {
                        value = xssAPI.encodeForHTML(i18n.getVar(elConf.getValue()));
                        caption =  xssAPI.encodeForHTMLAttr(i18n.getVar(elConf.getCaption()));
                        if(!StringUtils.isEmpty(value)) {%>
                            <td title="<%=caption%>" class='cm-texteditor-specialcharacter-cell'><button data-wysihtml5-command="insertText" data-wysihtml5-command-value="<%=value%>"><%=value%></button></td>
                        <%}
                    }
                }
            %>
            </tr><tr>
            <%
        }%>
        </tr>
    </table>
</div>
