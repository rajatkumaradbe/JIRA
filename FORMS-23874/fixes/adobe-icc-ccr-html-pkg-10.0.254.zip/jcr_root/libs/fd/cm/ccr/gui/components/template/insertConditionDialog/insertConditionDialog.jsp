<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div>
	<div class="modal-header" >
	    <h3>Insert Condition</h3>
	</div>
	<div class="modal-body">
		 <div>
            <label class="control-label" >{{I18n.getMessage("Condition Text")}}</label>
            <textarea style="height:60pt; min-width:165pt; overflow:auto;resize:none" type="text" ng-disabled="true" ng-model="model.conditionText" ></textarea>
          </div>
          <div>
			  <label class="control-label" >{{I18n.getMessage("Condition")}}</label>
			  <input type="text" ng-change="enableOkButton()" ng-model="model.condition">
          </div>
	</div>
	<div class="modal-footer">
	    <button class="btn btn-warning cancel" ng-disabled="conditionState" ng-click="processOk()">{{I18n.getMessage("Ok")}}</button>
	    <button class="btn btn-warning cancel" ng-click="processCancel()">{{I18n.getMessage("Cancel")}}</button>
	</div>
</div>