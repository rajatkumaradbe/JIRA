<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="modal-header">
    <h3>{{I18n.getMessage("Find And Replace")}}</h3>
</div>
<div class="modal-body">
    <form class="form-horizontal">
        <div>
            <label class="control-label" >{{I18n.getMessage("Search text")}}</label>
            <input type="text" ng-change="onFindValueChange()" ng-model="model.findInputText" >
        </div>
        <div>
            <label class="control-label" >{{I18n.getMessage("Replace with")}}</label>
            <input type="text" ng-change="onSelectionChange()" ng-model="model.replaceInputText">
        </div>
        <label class="checkbox"> <input type="checkbox" ng-change="onSelectionChange()" ng-model="model.caseSensitiveSelection">{{I18n.getMessage("Case sensitive")}}</label>
        <label class="checkbox"> <input type="checkbox" ng-change="onSelectionChange()" ng-disabled="!wholeWordEnabled" ng-model="model.wholeWordSelection">{{I18n.getMessage("Whole word")}}</label>
        <label class="checkbox"><input type="checkbox" ng-change="onRegExpSelectionChange()" ng-model="model.regExpSelection">{{I18n.getMessage("Regular expressions")}}</label>
        <label class="control-label findAndReplaceMessage" >{{message}}</label>
    </form>
</div>
<div class="modal-footer">
    <button class="btn btn-warning cancel" ng-disabled="isValid" ng-click="findButtonClickHandler()" >{{I18n.getMessage("Find")}}</button>
    <button class="btn btn-warning cancel" ng-disabled="isValid" ng-click="replaceButtonClickHandler()" >{{I18n.getMessage("Replace")}}</button>
    <button class="btn btn-warning cancel" ng-disabled="isValid" ng-click="replaceAllButtonClickHandler()">{{I18n.getMessage("Replace All")}}</button>
    <button class="btn btn-warning cancel" ng-click="closeClickHandler()">{{I18n.getMessage("Close")}}</button>
</div>