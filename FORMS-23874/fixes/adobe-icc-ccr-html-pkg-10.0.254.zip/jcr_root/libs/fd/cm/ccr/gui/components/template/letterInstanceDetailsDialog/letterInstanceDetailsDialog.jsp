<div class="modal fade" id="letterInstanceDetailsDialog" role="dialog" data-backdrop="static" aria-hidden="true" ng-controller="LetterInstanceDetailsCtrl">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" ng-click="closeLetterInstanceDetailsDialog()" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">{{letterInstanceNameTitle}}</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" name="letterInstanceForm">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <input type="text" name="input" ng-model="letterInstanceNameTextBox" class="form-control">
                            <p ng-show="letterInstanceNameError.length > 0" class="top20 no_margin-bottom alert-danger alert">{{letterInstanceNameError}}</p>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-block btn-lg" ng-click="onOkLetterInstanceNameDialog(letterInstanceNameTextBox)">{{I18n.getMessage("Done") }}</button>
            </div>
        </div>
    </div>
</div>
<script>
    //TODO Use Angular event instead of jQuery
    $(document).on('hidden.bs.modal', '#letterInstanceDetailsDialog', function(){
        var letterInstance = CCRSharedData.getInstance().letterInstance;
        letterInstance.trigger(new CMEvent("closeLetterInstanceDetailsDialog"));
    });
</script>