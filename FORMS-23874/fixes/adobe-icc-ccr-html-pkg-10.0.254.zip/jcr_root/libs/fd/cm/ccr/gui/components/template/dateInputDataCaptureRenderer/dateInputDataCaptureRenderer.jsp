<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ~ ADOBE CONFIDENTIAL
  ~  ___________________
  ~
  ~   Copyright 2015. Adobe Systems Incorporated
  ~   All Rights Reserved.
  ~
  ~  NOTICE:  All information contained herein is, and remains
  ~  the property of Adobe Systems Incorporated and its suppliers,
  ~  if any.  The intellectual and technical concepts contained
  ~  herein are proprietary to Adobe Systems Incorporated and its
  ~  suppliers and are protected by all applicable intellectual property
  ~  laws, including trade secret and copyright laws.
  ~  Dissemination of this information or reproduction of this material
  ~  is strictly forbidden unless prior written permission is obtained
  ~  from Adobe Systems Incorporated.
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<div class="dateInputField">
    <label>{{data.labelField }}</label>
    <div class="input-group dateInputContainer">
        <input data-somExp="{{data.formSomExp}}" type="text" class="form-control" title="{{data.toolTip}}" readonly="readonly" ng-disabled="{{!data.editable}}" ng-class="{ngInvalid : !data.dataTypeValid}" ng-model="data.dateValue"
               datepicker-options="dateOptions" uib-datepicker-popup="{{dateDisplayFormat()}}" ng-init="datePickerOpened = false" is-open="datePickerOpened" close-text="Close" />
        <span class="input-group-btn">
            <button type="button" class="btn btn-default" ng-click="datePickerOpened = true"><i class="glyphicon glyphicon-calendar"></i></button>
        </span>
    </div>
    <span class="help-block">{{ data.dataTypeError }}</span>

</div>